#Task 1b2
#order of n
inp_f = open('input1b2.txt')
out_f = open('output1b2.txt', 'w')
data = inp_f.readline().split(' ')

for i in range(len(data)):
    data[i] = int(data[i])
size = data[0]
sum = data[1]
lst_a = inp_f.readline().split(' ')

for i in range(size):
    lst_a[i] = int(lst_a[i])
dict_a = {}
arr = []
for i in range(size):
    arr.append(sum - (lst_a[i]))
for j in range(size):
    dict_a[lst_a[j]] = j

for h in range(size):
    if (arr[h] in lst_a) and (h != dict_a[arr[h]]):
        print(h + 1, dict_a[arr[h]] + 1, file = out_f)
        break
    else:
        print('IMPOSIBLE', file = out_f)
inp_f.close()
out_f.close()