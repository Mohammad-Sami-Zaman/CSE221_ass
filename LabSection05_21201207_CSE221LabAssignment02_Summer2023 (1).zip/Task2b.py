#Task 2b
#order of n
inp_f = open('input2b.txt')
out_f = open('output2b.txt', 'w')

size_1 = int(inp_f.readline())
data_1 = inp_f.readline().split(' ')
size_2 = int(inp_f.readline())
data_2 = inp_f.readline().split(' ')
data_3 = []

for i in range(len(data_1)):
    data_1[i] = int(data_1[i])
for i in range(len(data_2)):
    data_2[i] = int(data_2[i])
val_1 = 0
val_2 = 0
if size_1 >= size_2:
    min = size_2
else:
    min = size_1
for j in range(1, size_1 + size_2 - 1):
    if data_1[val_1] < data_2[val_2]:
        data_3.append(data_1[val_1])
        val_1 = val_1 + 1
        if val_1 > size_1 and val_1 >= val_2:
          data_3 += (data_2[val_2: : ])
    else:
        data_3.append(data_2[val_2])
        val_2 = val_2 + 1
        if val_2 > size_2 and val_2 > val_1:
          data_3 += (data_1[val_1: : ])
if val_1 == val_2:
    data_3 += (data_2[val_2: : ])
if val_1 < size_1 :
    data_3 += (data_1[val_1: : ])

if val_2 < size_2 :
    data_3 += (data_2[val_2: : ])

print(data_3, file = out_f)

inp_f.close()
out_f.close()