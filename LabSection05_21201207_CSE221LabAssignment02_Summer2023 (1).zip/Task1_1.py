#Task no 1a
# order of n^2
inp_f = open('input1a.txt')
out_f = open('output1a.txt', 'w')
data = inp_f.readline().split(' ')
for i in range(len(data)):
    data[i] = int(data[i])
size = data[0]
sum = data[1]
lst_a = inp_f.readline().split(' ')
for i in range(size):
    lst_a[i] = int(lst_a[i])
count = 0
for j in range(size):
    for h in range(j, size - 1, 1):
        if lst_a[j] + lst_a[h + 1] == sum:
            print(j + 1, h + 2, file = out_f)
            count = 1
            break
if count != 1:
            print('IMPOSIBLE', file = out_f)

inp_f.close()
out_f.close()