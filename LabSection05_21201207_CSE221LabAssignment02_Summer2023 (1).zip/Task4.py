#Task no 4
inp_f = open('input4.txt')
out_f = open('output4.txt', 'w')

size_1 = int(inp_f.readline())
arr = inp_f.readline().split(' ')
for i in range(len(arr)):
    arr[i] = int(arr[i])

def max(a, b):
    if a > b:
        max_v = a
    else:
        max_v = b

    return (max_v)

def mergeMax(arr):
    if len(arr) <= 1:
        return arr
    else:
        mid = len(arr) // 2
        a1 = mergeMax(arr[ : mid : ])  # write the parameter
        a2 = mergeMax(arr[mid : : ])  # write the parameter
        return max(a1, a2)
for i in mergeMax(arr):
    print( i , end = ' ', file = out_f)

inp_f.close()
out_f.close()