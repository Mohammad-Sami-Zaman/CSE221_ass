#task no 3
inp_f = open('input3.txt')
out_f = open('output3.txt', 'w')

size_1 = int(inp_f.readline())
arr = inp_f.readline().split(' ')
for i in range(len(arr)):
    arr[i] = int(arr[i])

def merge(a, b):
    val_1 = 0
    val_2 = 0
    data_3 = []
    if len(a) >= len(b):
        min = len(b)
    else:
        min = len(a)
    while val_1 < len(a) and val_2 < len(b) :
      if a[val_1] < b[val_2]:
        data_3.append(a[val_1])
        val_1 = val_1 + 1
        if val_1 > len(a) and val_1 >= val_2:
          data_3 += (b[val_2: : ])
      else:
        data_3.append(b[val_2])
        val_2 = val_2 + 1
        if val_2 > len(b) and val_2 > val_1:
          data_3 += (a[val_1: : ])
    if val_1 == val_2:
        data_3 += (b[val_2: : ])
    if val_1 < len(a) :
        data_3 += (a[val_1: : ])

    if val_2 < len(b):
        data_3 += (b[val_2: : ])

    return (data_3)

def mergeSort(arr):
    if len(arr) <= 1:
        return arr
    else:
        mid = len(arr) // 2
        a1 = mergeSort(arr[ : mid : ])  # write the parameter
        a2 = mergeSort(arr[mid : : ])  # write the parameter
        return merge(a1, a2)
for i in mergeSort(arr):
    print( i , end = ' ', file = out_f)

inp_f.close()
out_f.close()