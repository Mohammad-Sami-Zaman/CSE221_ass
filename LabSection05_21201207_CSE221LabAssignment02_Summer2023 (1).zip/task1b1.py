#Task 1b1
#order of nlogn
inp_f = open('input1b1.txt')
out_f = open('output1b1.txt', 'w')
data = inp_f.readline().split(' ')
for i in range(len(data)):
    data[i] = int(data[i])
size = data[0]
sum = data[1]
lst_a = inp_f.readline().split(' ')
for i in range(size):
    lst_a[i] = int(lst_a[i])
lst_a.sort()
lft = 0
rig = len(lst_a) - 1

for j in range(size):
     val = lst_a[lft] + lst_a[rig]
     if val == sum:
            print(lft + 1, (rig) + 1, file = out_f)
            break
     elif val < sum:
        lft = lft + 1
     elif val > sum:
        rig = rig - 1
if lft == size - 1 and rig == 0:
    print('IMPOSIBLE', file = out_f)
inp_f.close()
out_f.close()