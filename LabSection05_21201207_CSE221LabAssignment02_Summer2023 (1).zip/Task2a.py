#Task 2a
#order of n
inp_f = open('input2a.txt')
out_f = open('output2a.txt', 'w')

size_1 = int(inp_f.readline())
data_1 = inp_f.readline().split(' ')
size_2 = int(inp_f.readline())
data_2 = inp_f.readline().split(' ')
for i in range(len(data_1)):
    data_1[i] = int(data_1[i])
for i in range(len(data_2)):
    data_2[i] = int(data_2[i])
data_3 = data_1 + data_2

data_3.sort()
for i in data_3:
    print( i , end = ' ', file = out_f)

inp_f.close()
out_f.close()