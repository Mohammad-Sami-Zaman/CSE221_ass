# Task no 2
inp_f = open('input2.txt')
out_f = open('output2.txt', 'w')

stairs = int(inp_f.readline())
def ways_of_climbing(n):
    if n == 0:
        return 0
    if n == 1:
        return 1
    list_a = [0] * (n + 1)
    list_a[0] = 1
    list_a[1] = 1
    for i in range(2, n + 1):
        list_a[i] = list_a[i - 1] + list_a[i - 2]
    return list_a[n]

print(ways_of_climbing(stairs), file=out_f)
inp_f.close()
out_f.close()