# Task no 1
inp_f = open('input1.txt')
out_f = open('output1.txt', 'w')

ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])

val = inp_f.read().split('\n')

for i in range(len(val)):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])

def ver_connect(val, ver_edg):  #vertex edge connection
      global list_a
      list_a = [[] for key in range(ver_edg[0] + 1)]
      for i in range (ver_edg[1]):
          list_a[val[i][0]].append((int(val[i][1]), int(val[i][2])))
          list_a[val[i][1]].append((int(val[i][0]), int(val[i][2])))
      return list_a
graph = ver_connect(val, ver_edg)
total_cost = 0
storage = set()
storage.add(1)
while len(storage) < ver_edg[0]:
    min_cost = float('inf')
    low_city = None
    for par in storage:
        for chi, wei in graph[par]:
            if (chi not in storage) and (wei < min_cost):
                min_cost = wei
                low_city = chi
    storage.add(low_city)
    total_cost += min_cost
print(total_cost, file = out_f)

inp_f.close()
out_f.close()