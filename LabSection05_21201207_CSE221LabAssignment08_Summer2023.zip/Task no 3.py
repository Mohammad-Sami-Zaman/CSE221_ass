#Task no 3
inp_f = open('input3.txt')
out_f = open('output3.txt', 'w')
ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])

val = inp_f.readline().split(' ')

for i in range(len(val)):
    val[i] = int(val[i])
def min_coins_need(ver_edg, val):
    store = [float('inf')] * (ver_edg[1] + 1)
    store[0] = 0
    for i in range(1, ver_edg[1] + 1, 1):
        for coi in val:
            if i - coi < 0:
                pass
            else:
                store[i] = min(store[i], store[i - coi] + 1)
    if store[ver_edg[1]] != float('inf'):
        pass
    else:
        return -1
    return store[ver_edg[1]]
ans = min_coins_need(ver_edg, val)
print(ans, file = out_f)

inp_f.close()
out_f.close()