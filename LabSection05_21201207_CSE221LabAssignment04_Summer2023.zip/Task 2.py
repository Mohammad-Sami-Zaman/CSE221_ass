#Task no 2
#BFS
inp_f = open('input2.txt')
out_f = open('output2.txt', 'w')

ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])

val = inp_f.read().split('\n')

for i in range(len(val)):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])

def bfs(adj, start):
      vis = ['g']*(ver_edg[0] + 1)
      queue = []
      order_vis = []
      vis[start] = 'b'
      order_vis.append(start)
      queue.append(start)
      while queue != []:
            explore = queue.pop(0)
            for n in (adj[explore]):
                if vis[n] == 'g':
                    vis[n] = 'b'
                    order_vis.append(n)
                    queue.append(n)
      return order_vis


def ver_connect(val, ver_edg):
      dict_a = {key : [] for key in range(ver_edg[0] + 1)}
      for i in range (ver_edg[1]):
          dict_a[val[i][0]].append(val[i][1])
          dict_a[val[i][1]].append(val[i][0]) #both way dirction for forward-backward
      return dict_a

adj = ver_connect(val, ver_edg)
start = 1

visit = bfs(adj, start)
print(str(visit)[1:-1:], end=' ', file = out_f)

inp_f.close()
out_f.close()
#explain
#BFS terversal does not check last elem it checks by level and level
#to top bottom how many level can be terversed
#ver_connect funtion helps to connect with all other verteces
#for BFS queue is important when checking through the levels where queue always pop in frist elem