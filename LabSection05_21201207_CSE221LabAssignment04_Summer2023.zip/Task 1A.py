#Task no 1A
inp_f = open('input1a.txt')
out_f = open('output1a.txt', 'w')
ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])

val = inp_f.read().split('\n')

for i in range(len(val)):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])

arr = [[0 for i in range(ver_edg[0] + 1)] for j in range(ver_edg[0] + 1)]

for i in range(0, len(arr), 1):
    if i < len(val):
      count = val[i][0]
      arr[count][val[i][1]] = val[i][2]
for i in arr:
    print(i, file = out_f)
inp_f.close()
out_f.close()
# explanation
#here first input represents how many vertices and edge are taken
# and organaiging them in a 2d array of coresponding connections
#tihs code is alll about maping the vertices in a matrix from