#Task no 5
#finding shortest path
inp_f = open('input5.txt')
out_f = open('output5.txt', 'w')

ver_edg_desteny = inp_f.readline().split(' ')
for i in range(len(ver_edg_desteny)):
    ver_edg_desteny[i] = int(ver_edg_desteny[i])

desteny = ver_edg_desteny[2]
val = inp_f.read().split('\n')

for i in range(len(val)):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])

def bfs_run(adj, start, desteny):
      vis = [False]*(ver_edg_desteny[0]+1)
      par = [0]*(ver_edg_desteny[0]+1)
      queue = []
      queue.append(start)
      vis[start] = True
      while queue != []:
          poi = queue.pop(0)   # first one in stack
          for nei in adj.get(poi, []):   #.get(key, default)
                if not  vis[nei]:
                      queue.append(nei)
                      vis[nei] = True
                      par[nei] = poi
      if not  vis[desteny]:
            return -1, []
      way = [desteny]
      while par[desteny]:
          way.append(par[desteny])
          desteny = par[desteny]
      way.reverse()
      return (len(way) - 1, way)

def ver_connect(val, ver_edg_desteny):
    dict_a = {key : [] for key in range(ver_edg_desteny[0] + 1)}
    for i in range (ver_edg_desteny[1]):
        dict_a[val[i][0]].append(val[i][1])
        dict_a[val[i][1]].append(val[i][0])
    return dict_a

adj = ver_connect(val, ver_edg_desteny)
desteny = ver_edg_desteny[2]
start = 1
ans = bfs_run(adj, start, desteny)
time = ans[0]
short_path = ans[1]
print(f'Time : {time} \n Shortest Path : {str(short_path)}', file = out_f)

inp_f.close()
out_f.close()
#Explain
#in this code Bfs run is important where it checks all levels that helps to find shortest path
#when terversing the vertice"s that has visited it is marked and go on until it find the desteny if not the it reset
# the whole proccess move on in a new path