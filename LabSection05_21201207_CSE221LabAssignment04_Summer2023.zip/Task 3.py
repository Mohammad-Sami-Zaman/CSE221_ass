#TASK no 3
# DFS order
inp_f = open('input3.txt')
out_f = open('output3.txt', 'w')

ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])

val = inp_f.read().split('\n')

for i in range(len(val)):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])

def dfs(adj, start, vis = None, order_vis = None):
   if vis is None:
      vis = ['g']*(ver_edg[0] + 1)
   if order_vis is None:
      order_vis = []
   if vis[start] == 'g':
      vis[start] = 'b'
      order_vis.append(start)
      for nei in adj[start]:
           dfs(adj, nei, vis, order_vis)
   return order_vis

def ver_connect(val, ver_edg):
    dict_a = {key : [] for key in range(ver_edg[0] + 1)}
    for i in range (ver_edg[1]):
        dict_a[val[i][0]].append(val[i][1])
        dict_a[val[i][1]].append(val[i][0]) #both way dirction for forward-backward
    return dict_a

adj = ver_connect(val, ver_edg)
start = 1
visit = dfs(adj, start)
print(str(visit)[1:-1:], end=' ', file = out_f)

inp_f.close()
out_f.close()
#Explain
#DFS terversal towards the highest depth as possible
#it do not go through by level by level
#it depends on stack base where we check if it can go through last part and when job is done the last elem is poped