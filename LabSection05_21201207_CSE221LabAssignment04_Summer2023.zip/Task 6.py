 # Task no 6
inp_f = open('input6.txt')
out_f = open('output6.txt', 'w')
r, c = map(int, inp_f.readline().strip().split())
list_a = []
for i in inp_f:
      list_a.append([j for j in i.strip()])

def dfs_flood(s, t):
    global r, c
    if s < 0 or s >= r or t < 0 or t >= c:
        return
    elif list_a[s][t] == '#':
        return
    else:
        if list_a[s][t] == 'D':
            global dimond
            dimond += 1
        list_a[s][t] = '#'
        dfs_flood(s + 1, t)
        dfs_flood(s - 1, t)
        dfs_flood(s, t +1)
        dfs_flood(s, t - 1)
        return dimond

def flood_fill():
      global r, c, dimond
      d_arr = []
      for s in range(r):
          for t in range(c):
              dimond = 0
              if list_a[s][t] != '#':
                  dfs_flood(s, t)
                  d_arr.append(dimond)
      return d_arr
max_d = max(flood_fill())
print (f'{max_d}', file = out_f)
inp_f.close()
out_f.close()
#explain
#max dimond will call dfs run which will explore adj list elem
#until finding and updating the dimond count and apppend in a list
#where using max funtion to give the ans value