# Task no 4
#(Cycle Finding)
inp_f = open('input4.txt')
out_f = open('output4.txt', 'w')

ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])

val = inp_f.read().split('\n')

for i in range(len(val)):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])

def terversal(adj):
      vis = []
      stack = []
      def dfs_cycle(node):
          vis.append(node)
          stack.append(node)
          for nei in adj[node]:
              if nei in stack:
                  return True
              if nei not in vis:
                  if dfs_cycle(nei) == True:
                      return True

          stack.pop()
          return False
      for n in adj:
          if n not in vis:
              if dfs_cycle(n):
                  return 'Yes'
      return 'No'

def ver_connect(val, ver_edg):
    dict_a = {key : [] for key in range(ver_edg[0] + 1)}
    for i in range (ver_edg[1]):
        dict_a[val[i][0]].append(val[i][1])
    return dict_a

adj = ver_connect(val, ver_edg)
start = 1
visit = terversal(adj)
print(visit, file = out_f)

inp_f.close()
out_f.close()
#Explain
#For checking cycle we run dfs terverse because it tervsre only one at a time
#in Dfs stack helps to whether the graph has cycle or not
#in stck ansd created list checks the result