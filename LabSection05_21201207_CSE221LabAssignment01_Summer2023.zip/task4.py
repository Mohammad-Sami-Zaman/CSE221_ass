#Task no 4
inp_f = open('input4.txt')
out_f = open('output4.txt', 'w')
size = int(inp_f.readline())
trains = [inp_f.readline().strip() for i in range(1, size + 1)]
for idx in range(len(trains)):
    for t in range(0, len(trains) - idx -1):
        val_1 = trains[t].split(' ')
        val_2 = trains[t + 1].split(' ')
        if val_2[0] < val_1[0]:
             trains[t], trains[t + 1] = trains[t + 1], trains[t]
        elif  val_2[0] == val_1[0] and val_2[-1] > val_1[-1]:
            trains[t], trains[t + 1] = trains[t + 1], trains[t]

for train in trains:
    print(train, file = out_f)
inp_f.close()
out_f.close()