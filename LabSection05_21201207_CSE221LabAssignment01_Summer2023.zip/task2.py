#Task 2

# if we use flag method by taking a default value 1 that means the array is already been sorted
# if the flag value is 0 then the arr is not sorted
# if the arr is already sorted then the flag value 1 its true and for the best case the run time will be θ(n)
#if the flag value is 1 then for the first step the sorting will end it does not need to run θ(n^2) times
with open('output2.txt', 'w') as out_f:
    with open('input2.txt') as inp_f:
        size = inp_f.readline()
        arr = inp_f.readline().split(' ')
        def bubbleSort(arr):
            check = 1
            for i in range (len(arr) -1):
                for j in range(len(arr) - i - 1):
                    if int(arr[j]) > int(arr[j+1]):
                        (arr[j]), (arr[j + 1]) = int(arr[j + 1]), int(arr[j])
                        check = 0
                if check == 1:
                    break
            arr[len(arr) -1] = int(arr[len(arr) -1])
            for i in arr:
                    print(i, end = ' ', file = out_f)
        bubbleSort(arr)