#Task no 1\B
inp_f = open('input1b.txt')
out_f = open('output1b.txt', 'w')
lines = int(inp_f.readline())
for i in range(0, lines):
    cal_x = inp_f.readline()
    cal = cal_x.split('calculate ')
    values = cal[1].split(' ')
    for j in range(len(values)):
         if '+' in values:
            sum = int(values[0]) + int(values[2])
         elif '-' in values:
            sum = int(values[0]) - int(values[2])
         elif '*' in values:
            sum = int(values[0]) * int(values[2])
         elif '/' in values:
            sum = int(values[0]) / int(values[2])
    print(f'The result of {cal[1]} is {sum}\n', file = out_f)
inp_f.close()
out_f.close()