#Task no 1\A
inp_f = open('input1a.txt')
out_f = open('output1a.txt', 'w')
lines = int(inp_f.readline())
for i in range(0, lines):
    number = int(inp_f.readline())
    if number % 2 == 0:
        print(number, 'is an Even number', file = out_f)
    else:
        print(number, 'is an Odd number', file = out_f)
inp_f.close()
out_f.close()