#Task 3
inp_f = open('input3.txt')
out_f = open('output3.txt', 'w')
size = int(inp_f.readline())
val = inp_f.readlines()
arr_1_id = val[0].strip().split(' ')
arr_2_marks = val[1].strip().split(' ')

for i in range (size):
    arr_1_id[i] = int(arr_1_id[i])
    arr_2_marks[i] = int(arr_2_marks[i])

for j in range(1, len(arr_2_marks), 1):
    if ( arr_2_marks[j - 1] == arr_2_marks[j] ):
      for i in range(j, size, 1):
        if (arr_1_id[i-1] > arr_1_id[i]):
            arr_1_id[i-1], arr_1_id[i] = arr_1_id[i], arr_1_id[i-1]
    elif arr_2_marks[j - 1] < arr_2_marks[j]:
            arr_2_marks[j-1], arr_2_marks[j] = arr_2_marks[j], arr_2_marks[j-1]
            arr_1_id[j-1], arr_1_id[j] = arr_1_id[j], arr_1_id[j-1]
for d in range(1, len(arr_2_marks), 1):
      if ( arr_2_marks[d - 1] == arr_2_marks[d] ):
          if (arr_1_id[d-1] > arr_1_id[d]):
            arr_1_id[d-1], arr_1_id[d] = arr_1_id[d], arr_1_id[d-1]

for i in range (size):
    print(f'ID: {arr_1_id[i]} Mark: {arr_2_marks[i]}', file = out_f)

inp_f.close()
out_f.close()