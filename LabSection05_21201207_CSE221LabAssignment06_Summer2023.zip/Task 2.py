#Task no 2
#Meet each other in the minimum amount of time
import math
from queue import PriorityQueue
inp_f = open('input2.txt')
out_f = open('output2.txt', 'w')

ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])

val = inp_f.read().split('\n')

for i in range(len(val)-1):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])
start = int(val[-1][0])
des = int(val[-1][2]) # did not split anything so as str 1 2 3 where 2 = ' '

def ver_connect(val, ver_edg):  #vertex edge connection
      dict_a = {key : [] for key in range(ver_edg[0] + 1)}
      for i in range (ver_edg[1]):
          dict_a[val[i][0]].append(val[i][1])
      return dict_a

con_graph = ver_connect(val, ver_edg)
adj = [None]*(ver_edg[0] + 1)

for i in range(ver_edg[1]):
    if adj[val[i][0]] == None:
         adj[val[i][0]] = [(str(val[i][1]), val[i][2])]
    else:
         adj[val[i][0]].append((str(val[i][1]), val[i][2]))

def dijkstra(start, adj, count):
    list_a = [math.inf]*(ver_edg[0] + 1)
    queue = PriorityQueue()
    queue.put((count, start))
    while not queue.empty():
        var, start = queue.get()
        if list_a[int(start)] <= var:
            pass
        else:
            list_a[int(start)] = var
            if adj[int(start)] == None:
                pass
            else:
                for i in adj[int(start)]:
                    start, up_var = i
                    queue.put((up_var + var, start))
    return list_a

fst_per = dijkstra(start, adj, 0)
scd_per = dijkstra(des, adj, 0)
meet_up = 0
total_time = math.inf

for i in range(len(fst_per)):
    if fst_per[i] == math.inf and scd_per[i] == math.inf:
        pass
    else:
        temp = max(fst_per[i], scd_per[i])
        if total_time > temp:
            meet_up = i
            total_time = temp

if meet_up == 0:
    print('Impossible', end = ' ', file = out_f)
else:
    print('Time ', total_time, file = out_f)
    print('Node ', meet_up, file = out_f)

inp_f.close()
out_f.close()