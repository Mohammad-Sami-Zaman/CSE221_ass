# Task no 1
#Dijkstra Algorithm
import math
from queue import PriorityQueue
inp_f = open('input1.txt')
out_f = open('output1.txt', 'w')

ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])

val = inp_f.read().split('\n')

for i in range(len(val)-1):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])
start = int(val[-1])

def ver_connect(val, ver_edg):  #vertex edge connection
      dict_a = {key : [] for key in range(ver_edg[0] + 1)}
      for i in range (ver_edg[1]):
          dict_a[val[i][0]].append(val[i][1])
      return dict_a

con_graph = ver_connect(val, ver_edg)
adj = [None]*(ver_edg[0] + 1)

for i in range(ver_edg[1]):
    if adj[val[i][0]] == None:
         adj[val[i][0]] = [(str(val[i][1]), val[i][2])]
    else:
         adj[val[i][0]].append((str(val[i][1]), val[i][2]))

def dijkstra(start, adj, count):
    list_a = [math.inf]*(ver_edg[0] + 1)
    queue = PriorityQueue()
    queue.put((count, start))
    while not queue.empty():
        var, start = queue.get()
        if list_a[int(start)] <= var:
            pass
        else:
            list_a[int(start)] = var
            if adj[int(start)] == None:
                pass
            else:
                for i in adj[int(start)]:
                    start, up_var = i
                    queue.put((up_var + var, start))
    return list_a
ans = dijkstra(start, adj, 0)
for j in range(1, len(ans), 1):
    if ans[j] == math.inf:
        print(-1, end = ' ', file = out_f)
    else:
        print(ans[j], end = ' ', file = out_f)

inp_f.close()
out_f.close()