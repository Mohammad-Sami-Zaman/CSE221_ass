#Task no 3
#ONE safest path the minimum danger level among all
#the paths from node 1 to node N.

import math
from queue import PriorityQueue
inp_f = open('input3.txt')
out_f = open('output3.txt', 'w')

ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])

val = inp_f.read().split('\n')

for i in range(len(val)):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])

def ver_connect(val, ver_edg):  #vertex edge connection
      dict_a = {key : [] for key in range(ver_edg[0] + 1)}
      for i in range (ver_edg[1]):
          dict_a[val[i][0]].append((int(val[i][2]), int(val[i][1])))
      return dict_a

con_graph = ver_connect(val, ver_edg)
adj = [None]*(ver_edg[0] + 1)

for i in range(ver_edg[1]):
    if adj[val[i][0]] == None:
         adj[val[i][0]] = [(str(val[i][1]), val[i][2])]
    else:
         adj[val[i][0]].append((str(val[i][1]), val[i][2]))

def min_danger_path(con_graph, start):
    vis = [math.inf]*(ver_edg[0] + 1)
    vis[start] = 0
    list_a = []
    queue = PriorityQueue()
    queue.put((0, start))
    while not queue.empty():
        point = queue.get()
        list_a.append(point[1])
        if point[0] >= vis[point[1]]:
            pass
        else:
            vis[point[1]] = point[0]
        for j in con_graph[point[1]]:
            edge = max(point[0], j[0])
            if j[1] not in list_a:
                queue.put((edge, j[1]))
    return vis[-1]

start = 1
ans = min_danger_path(con_graph, start)
print(ans, file = out_f)

inp_f.close()
out_f.close()