#Task no 2
inp_f = open('input2.txt')
out_f = open('output2.txt', 'w')

size = int(inp_f.readline())
arr = inp_f.readline().split(' ')
for i in range(len(arr)):
    arr[i] = int(arr[i])

val = 0
val_max = 0
temp = arr[0]
i = 0
j = 1
while j < len(arr):
    if (arr[j]**2) >= val_max:
        val = arr[j]
        i = j
        val_max = arr[j]**2
    j += 1
t = 0
while t < i:
    if arr[t] > temp:
        temp = arr[t]
    t += 1
ans = val_max + temp
print(ans, file = out_f)
inp_f.close()
out_f.close()

#Discussion:
#in this task takinf vals that will preserves values like i and Val_max is result value of j**2
#for fast loop we just finding the maximum j value and perserving j previous value at i as i < j
#in the code i and j are indexes
# at the second loop we looping between i index that is to find the second max absolute value