#Task no 1
inp_f = open('input1.txt')
out_f = open('output1.txt', 'w')
size = int(inp_f.readline())
arr = inp_f.readline().split(' ')
for i in range(len(arr)):
    arr[i] = int(arr[i])

def mergeSort(arr):
    if len(arr) <= 1:
        return arr, 0
    else:
        mid = len(arr) // 2

        a1, lft_count = mergeSort(arr[ : mid : ])  # write the parameter
        a2, rig_count = mergeSort(arr[mid : : ])  # write the parameter
        a3 = []
        main_count = lft_count + rig_count
        lft = 0
        rig = 0
        while lft < len(a1) and rig < len(a2):
            if (a1[lft]) <= (a2[rig]):
                a3.append(a1[lft])
                lft = lft + 1
            else:
                a3.append(a2[rig])
                rig = rig + 1
                main_count += len(a1) - lft
        a3 += a1[lft: : ] + a2[rig: : ]
        return a3 , main_count
def count_alien(size, arr):
    maincount = mergeSort(arr)
    return maincount[1]

print(count_alien(size, arr), file = out_f)

inp_f.close()
out_f.close()
#Disscussion
#In this task by using mergesort i am dividing arr in to samllest possible and checking all elements in a singuler
#serial tersal and counting the aliens presents there in recursive way and return merged sorted arr and counts of alien
#at last function we are just retuning the alien values