#Task3
inp_f = open('input3.txt')
out_f = open('output3.txt', 'w')
size = int(inp_f.readline())
arr = inp_f.readline().split(' ')
for i in range(len(arr)):
    arr[i] = int(arr[i])

def partition(arr, lil, tal):
    val = arr[tal]
    a = lil - 1
    b = lil
    while b < tal:
        if arr[b] < val:
            a = a + 1
            arr[a], arr[b] = arr[b], arr[a]
        b += 1
    arr[a + 1], arr[tal] = arr[tal], arr[a + 1]
    return a + 1

def quickSort(arr, small, big):
  if small < big:
    val_q = partition(arr, small, big)
    quickSort(arr, small, val_q - 1)
    quickSort(arr, val_q + 1, big)
quickSort(arr, 0, size - 1)
for elem in arr:
    print(elem, end=' ', file=out_f)

inp_f.close()
out_f.close()

# explain
#by using quicksort we are sorting the arr as much as possible and here we are dividing like merge sort algorithm
#in partition function we are just taking an element as a pivot and making other elem to arrange them in a way if the
#pivot value is larger then an elem then elem will put left side vice versa to other