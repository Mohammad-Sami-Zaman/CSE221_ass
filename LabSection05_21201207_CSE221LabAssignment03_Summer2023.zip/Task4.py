# Task no 4
inp_f = open('input4.txt')
out_f = open('output4.txt', 'w')

size_1 = int(inp_f.readline())
arr = inp_f.readline().split(' ')

for i in range(len(arr)):
    arr[i] = int(arr[i])
quary_a = int(inp_f.readline())
read_f = inp_f.readlines()

def partition(arr, lil, tal):
    val = arr[tal]
    a = lil - 1
    b = lil
    while b < tal:
        if arr[b] < val:
            a = a + 1
            arr[a], arr[b] = arr[b], arr[a]
        b += 1
    arr[a + 1], arr[tal] = arr[tal], arr[a + 1]
    return a + 1

def find_small(arr, q):
    small = 0
    big = len(arr) - 1

    while True:
        piot = partition(arr, small, big)
        if piot == q - 1:
            return arr[piot]
        elif piot > q - 1:
            big = piot - 1
        else:
            small = piot + 1

for i in range(quary_a):
    q = int(read_f[i])
    result = find_small(arr, q)
    print(result, file = out_f)
inp_f.close()
out_f.close()
#explain
#just like quick sort we are sorting as much as possible and last it is sorted nearly we can the queta amount find the
#asked maximum value in a way how many that wanted to know