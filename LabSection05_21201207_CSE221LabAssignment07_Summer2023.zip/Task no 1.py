# Task no 1
inp_f = open('input1.txt')
out_f = open('output1.txt', 'w')
#input
ver_edg = inp_f.readline()
ver_edg = int(ver_edg)
val = inp_f.read().split('\n')
list_a = []
for i in range(len(val)):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])
    list_a.append((val[i][0], val[i][1]))
#sorting all the start and end time by the basis of end time assending order
for idx in range(0, len(list_a), 1):
    for j in range(0, len(list_a) - idx - 1):
        if list_a[j][1] > list_a[j + 1][1]:
            list_a[j], list_a[j + 1] = list_a[j+1], list_a[j]
#finding efficient times by comparing first start and second end time
fin = -1
list_b = []
for sch in list_a:
    if sch[0] >= fin:
        list_b.append(sch)
        fin = sch[1]
# Out put
print(len(list_b), file = out_f)
for i in list_b:
    txt = ''
    for j in i:
      txt += str(j) + ' '
    print(txt, file = out_f)

inp_f.close()
out_f.close()