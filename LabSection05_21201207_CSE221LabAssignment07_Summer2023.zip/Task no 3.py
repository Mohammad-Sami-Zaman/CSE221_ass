#Task no 3
inp_f = open('input3.txt')
out_f = open('output3.txt', 'w')
#input
ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])
val = inp_f.read().split('\n')
list_a = []
for i in range(len(val)):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])
    list_a.append((val[i][0], val[i][1]))

list_b = [None]*(ver_edg[0] + 1)
for idx in range(0, ver_edg[0] + 1, 1):
    list_b[idx] = idx
dict_a = {}
for i in range(1, ver_edg[0] + 1):
    dict_a[i] = {i}

for j in range(0, ver_edg[1], 1):
    m = val[j][0]
    n = val[j][1]
    par = list_b[m]
    chi = list_b[n]
    for i in dict_a[chi]:
        dict_a[par].add(i)
        list_b[n] = m
    ans = len(dict_a[par])
    print(ans, file = out_f)

inp_f.close()
out_f.close()