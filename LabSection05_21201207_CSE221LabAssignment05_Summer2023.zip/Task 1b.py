# Task no 1B
# BFS RUN
inp_f = open('input1b.txt')
out_f = open('output1b.txt', 'w')

ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])

val = inp_f.read().split('\n')

for i in range(len(val)):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])
def topology_bfs_sort(vertice, connect):
      adj = {}
      in_deg = [0]*(vertice + 1)
      list_a = []
      for i in range(1, vertice + 1):
          adj[i] = []
      for v, c in connect:
            adj[v].append(c)
            in_deg[c] += 1
      queue = []
      for start in range(1, len(adj) + 1):
          if in_deg[start] == 0 :
              queue.append(start)
      while queue :
          cou = queue.pop(0)
          list_a.append(cou)
          for nei in adj[cou]:
              in_deg[nei] = in_deg[nei] - 1
              if in_deg[nei] == 0:
                  queue.append(nei)
      return list_a
ans = topology_bfs_sort(ver_edg[0], val)
if len(ans) == ver_edg[0]:
      print(f'{str(ans)[1 : -1 : ]}', file = out_f)
else:
      print('IMPOSSIBLE', file = out_f)
inp_f.close()
out_f.close()