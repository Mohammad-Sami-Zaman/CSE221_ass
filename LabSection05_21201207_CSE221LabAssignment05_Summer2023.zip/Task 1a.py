# Task no 1A
# DFS RUN
inp_f = open('input1a.txt')
out_f = open('output1a.txt', 'w')

ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])

val = inp_f.read().split('\n')

for i in range(len(val)):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])

def cycle(adj):         #grapgh cycle check
      vis = []
      stack = []
      def dfs_cycle(node):
          vis.append(node)
          stack.append(node)
          for nei in adj[node]:
              if nei in stack:
                  return True
              if nei not in vis:
                  if dfs_cycle(nei) == True:
                      return True
          stack.pop()
          return False
      for n in adj:
          if n not in vis:
              if dfs_cycle(n):
                  return 'Yes'
      return 'No'

def dfs_run(n):
          vis[n] = True
          for nei in adj[n]:
              if not vis[nei]:
                  dfs_run(nei)
          list_a.append(n)
          return list_a

def topology_sort(adj):
      global vis, list_a, in_deg
      vis = [False]*(ver_edg[0] + 1)
      in_deg = [0]*(ver_edg[0] + 1)
      list_a = []
      for m in adj:
          for s in adj[m]:
              in_deg[s] += 1
      for n in range(1, ver_edg[0] + 1):
          if not vis[n]:
              dfs_run(n)
      list_a.reverse()
      return list_a

def ver_connect(val, ver_edg):  #vertex edge connection
      dict_a = {key : [] for key in range(ver_edg[0] + 1)}
      for i in range (ver_edg[1]):
          dict_a[val[i][0]].append(val[i][1])
      return dict_a
global adj
adj = ver_connect(val, ver_edg)
ans = topology_sort(adj)
res = ' '
if cycle(adj) == 'Yes':
      print('IMPOSSIBLE', file = out_f)
else:
    if len(ans) == ver_edg[0]:
      for i in range(0, len(ans)-1):
        if in_deg[ans[i]] > in_deg[ans[i+1]]:
              ans[i], ans[i+1] = ans[i+1], ans[i]
      print(f'{str(ans)[1 : -1 : ]}', file = out_f)

inp_f.close()
out_f.close()