# Task no 3
inp_f = open('input3.txt')
out_f = open('output3.txt', 'w')

ver_edg = inp_f.readline().split(' ')
for i in range(len(ver_edg)):
    ver_edg[i] = int(ver_edg[i])

val = inp_f.read().split('\n')

for i in range(len(val)):
    val[i] = ((val[i]).split(' '))
    for j in range(len(val[i])):
        val[i][j] = int(val[i][j])

def dfs_run_1(adj, n, vis, stack):
    vis[n] = True
    for nei in adj[n]:
        if not vis[nei]:
            dfs_run_1(adj, nei, vis, stack)
    stack.append(n)

def dfs_run_2(rev_adj, m, new_vis, conn):
      new_vis[m] = True
      conn.append(m)
      for nei in rev_adj[m]:
          if not new_vis[nei]:
              dfs_run_2(rev_adj, nei, new_vis, conn)

def strongly_connect(adj, rev_adj):
    vis = [False]*(ver_edg[0]+1)
    stack = []
    for n in range(1, ver_edg[0]+1):
        if not vis[n]:
            dfs_run_1(adj, n, vis, stack)

    new_vis = [False]*(ver_edg[0]+1)
    list_a = []
    while stack != []:
        start = stack.pop()
        if not new_vis[start]:
            conn = []
            dfs_run_2(rev_adj, start, new_vis, conn)
            list_a.append(conn)
    return list_a

def ver_connect(val, ver_edg):  #vertex edge connection
      global dict_a
      dict_a = {key : [] for key in range(ver_edg[0] + 1)}
      for i in range (ver_edg[1]):
          dict_a[val[i][0]].append(val[i][1])
      return dict_a
def ver_connect_reverse(val, ver_edg):  #vertex edge connection reversely
      global dict_b
      dict_b = {key : [] for key in range(ver_edg[0] + 1)}
      for i in range (ver_edg[1]):
          dict_b[val[i][1]].append(val[i][0])
      return dict_b

adj = ver_connect(val, ver_edg)
rev_adj = ver_connect_reverse(val, ver_edg)
ans = strongly_connect(adj, rev_adj)
for i in ans:
    i.sort()
    print(f"{str(i)[1 : -1: ]}", file = out_f)

inp_f.close()
out_f.close()